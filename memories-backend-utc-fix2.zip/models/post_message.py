import mongoengine as me
import datetime

class PostMessage(me.Document):
    title = me.StringField(required=True)
    message = me.StringField(required=True)
    name = me.StringField(required=True) # Corresponds to the name of the user who created the post
    creator = me.StringField(required=True) # Corresponds to the ID of the user who created the post
    tags = me.ListField(me.StringField())
    selectedFile = me.StringField() # Assuming this is a base64 string or a URL
    likes = me.ListField(me.StringField(), default=list) # List of user IDs who liked the post
    comments = me.ListField(me.StringField(), default=list) # List of comments (strings)
    createdAt = me.DateTimeField(default=lambda: datetime.datetime.now(datetime.timezone.utc))

    # Meta information for MongoEngine, like the collection name
    meta = {
        'collection': 'postmessages', # Explicitly set collection name if it differs from class name
        'strict': False # Allow extra fields from DB (like __v from Mongoose)
    }

    def to_json_serializable(self):
        post_dict = self.to_mongo().to_dict()
        if '_id' in post_dict:
            post_dict['id'] = str(post_dict['_id'])
            del post_dict['_id']
        if 'createdAt' in post_dict and isinstance(post_dict['createdAt'], datetime.datetime):
            post_dict['createdAt'] = post_dict['createdAt'].isoformat()
        # Handle other non-serializable fields if any
        return post_dict

    # Additional methods can be added here as needed

    # ... rest of the original file content ... 