from mongoengine import Document, StringField, ListField, DateTimeField
import datetime

class PostMessage(Document):
    title = StringField()
    message = StringField()
    name = StringField() # Corresponds to the name of the user who created the post
    creator = StringField() # Corresponds to the ID of the user who created the post
    tags = ListField(StringField())
    selectedFile = StringField() # Assuming this is a base64 string or a URL
    likes = ListField(StringField(), default=list) # List of user IDs who liked the post
    comments = ListField(StringField(), default=list) # List of comments (strings)
    createdAt = DateTimeField(default=datetime.datetime.utcnow) # Automatically set on creation

    # Meta information for MongoEngine, like the collection name
    meta = {
        'collection': 'postmessages' # Explicitly set collection name if it differs from class name
    } 